cd bin
java -jar analysis.jar "$@"