javac SequentialAnalysis.java
java SequentialAnalysis "$@"